About:
This patches for removing ads from apps
Created by TheDarkOnion
Ping me on Telegram t.me/TheDarkOnion

Introduction:
1. First try RemoveAds-R1
2. If you face any problem of crash or server error with RemoveAds-R1 then try RemoveAds-R2
3. RemoveAds-R3 is enough for disabling ads and safe from errors
4. DisableInternet patch will make your application into offline mode

Thanks:
Specially thanks to Indian guy MuhammadRizwan87