# This script, created by https://Its_me_MuhammadRizwan.t.me is designed to patch executable libraries of Android apps and games, and can be particularly useful for Modders. 

# To use this script, you will need to have radare2 and r2pipe installed. You can find instructions for installing radare2 at https://t.me/TDOhex/280 and for installing r2pipe, run the command `pip install r2pipe`

# Here's how to use the script:
# 1. Extract the executable library into your directory
# 2. Add your file path to the "file_path" variable
# 3. Add the necessary offsets to the "offsets" variable
# 4. Run the script with the command `python patcher32.py`

# Please feel free to provide feedback or ask any questions in our discussion group at https://TDOhex_Discussion.t.me And don't forget to visit our main channel at https://TDOhex.t.me

# Finally, note that this script requires a certain level of technical knowledge and expertise to use properly. It is recommended for professional Modders who are comfortable working with these tools and making changes to executable libraries.


import r2pipe
import time

def check_file_architecture(file_path, expected_arch):
    r2 = r2pipe.open(file_path)  # Open the file in radare2

    info_json = r2.cmdj("ij")  # Get JSON info about the file
    arch = info_json.get("bin", {}).get("machine", "")  # Get the architecture from the info

    r2.quit()  # Close the radare2 session

    return arch == expected_arch

def set_values_to_offsets(file_path, offsets):
    # Check file architecture before proceeding
    if not check_file_architecture(file_path, "ARM"):
        print("The file architecture is not 'armeabi-v7a'. Aborting script.")
        return

    start_time = time.time()  # Start measuring script execution time

    r2 = r2pipe.open(file_path)  # Open the file in radare2
    r2.cmd("oo+")  # Reopen the file in read-write mode

    for data_type, offset_list in offsets.items():
        if data_type == "boolean_true":
            for offset in offset_list:
                r2.cmd(f"wx 0100A0E31EFF2FE1 @ {offset}")  # Set boolean true at each offset
                # mov r0, 1
                # bx lr
        elif data_type == "boolean_false":
            for offset in offset_list:
                r2.cmd(f"wx 0000A0E31EFF2FE1 @ {offset}")  # Set boolean false at each offset
                # mov r0, 0
                # bx lr
        elif data_type == "integer_zero":
            for offset in offset_list:
                r2.cmd(f"wx 0000A0E31EFF2FE1 @ {offset}")  # Set zero integer value at each offset
                # mov r0, 0
                # bx lr
        elif data_type == "integer16_max":
            for offset in offset_list:
                r2.cmd(f"wx FF0F07E31EFF2FE1 @ {offset}")  # Set maximum integer (16-bit) value at each offset
                # movw r0, 0x7fff
                # bx lr
        elif data_type == "integer32_max":
            for offset in offset_list:
                r2.cmd(f"wx FF0F0FE3FF0F47E31EFF2FE1 @ {offset}")  # Set maximum integer (32-bit) value at each offset
                # movw r0, 0xffff
                # movt r0, 0x7fff
                # bx lr
        elif data_type == "long_zero":
            for offset in offset_list:
                r2.cmd(f"wx 0000A0E31EFF2FE1 @ {offset}")  # Set zero long value at each offset
                # mov r0, 0
                # bx lr
        elif data_type == "long_64":
            for offset in offset_list:
                r2.cmd(f"wx 0201E0E31EFF2FE1 @ {offset}")  # Set long (64-bit) value at each offset
                # mvn r0, 0x80000000
                # bx lr
        elif data_type == "float_zero":
            for offset in offset_list:
                r2.cmd(f"wx 0000A0E31EFF2FE1 @ {offset}")  # Set zero float value at each offset
                # mov r0, 0
                # bx lr
        elif data_type == "double_zero":
            for offset in offset_list:
                r2.cmd(f"wx 0000A0E31EFF2FE1 @ {offset}")  # Set zero double value at each offset
                # mov r0, 0
                # bx lr
        elif data_type == "void_nop":
            for offset in offset_list:
                r2.cmd(f"wx 1EFF2FE1 @ {offset}")  # Set void with nop
                # bx lr
        else:
            print(f"Unknown data type: {data_type}")

    r2.quit()  # Close the radare2 session

    execution_time = time.time() - start_time  # Calculate script execution time
    print(f"Patches Applied!\nScript execution time: {execution_time:.2f} seconds")

# Replace with your file path
file_path = "/storage/emulated/0/radare2/libil2cpp.so"

# Put offsets as needed
offsets = {
    "boolean_true": [0x100, 0x200], # Example of multiple offsets
    "boolean_false": [0x300], # Example of single offset
    "integer_zero": [], # Leave empty if not needed
    "integer16_max": [],
    "integer32_max": [],
    "long_zero": [],
    "long_64": [],
    "float_zero": [],
    "double_zero": [],
    "void_nop": []
}
set_values_to_offsets(file_path, offsets)
